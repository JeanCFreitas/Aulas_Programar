class animal:
    def som(self):
        pass
class cachorro(animal):
    def emitir_som(self):
        print("Au")
class gato(animal):
    def emitir_som(self):
        print("miau")