class pessoa:
    def exibir_informacoes(self, idade, nome):
        self.idade = 30
        self.nome = sefg