class conta_bancaria:
    def __saldo(self, titular, saldo):
        self.marca = fiat
        self.modelo = uno