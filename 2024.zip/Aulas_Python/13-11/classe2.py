class carro:
    def _init_(self, marca, modelo, ano):
        self.marca = fiat
        self.modelo = uno
        self.ano= 1995
    def detalhes(self):
        print (f'marca: {self.marca}, modelo: {self.modelo}, ano: {self.ano}')