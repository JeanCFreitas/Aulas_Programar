def barulho(meu_nome):
  def animal(self):
    