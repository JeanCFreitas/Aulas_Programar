fahrenheit = float(input("Digite a temperatura em graus Fahrenheit:"))
celsius = ((fahrenheit - 32)*5)/9
print("Temperatura em Celsius:", celsius,"ºC")