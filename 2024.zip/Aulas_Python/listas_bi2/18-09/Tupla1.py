numeros = (10, 20, 30, 40, 50)
terceito_elemento = numeros[2]
presenca_20=20 in numeros
lista_numeros=list(numeros)
print(terceito_elemento)
print(presenca_20)
print(lista_numeros)