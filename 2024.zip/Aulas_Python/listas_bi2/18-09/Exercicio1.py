#Criar Lista
lista = list(range(1,11))
#Adicionar o numero 11 ao final da lista
lista.append(11)
#remover numero 5 da lista
lista.remove(5)
#inverter a ordem dos elementos da lista
lista.reverse()

print(lista)