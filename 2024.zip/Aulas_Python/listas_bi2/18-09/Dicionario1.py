dicionario={'nome': 'João', 'idade': '25', 'cidade': 'São Paulo', 'profissão': 'Bombeiro'}
dicionario['profissão'] = 'Engenheiro'
dicionario['idade']='26'
dicionario.pop('cidade')
print(dicionario)