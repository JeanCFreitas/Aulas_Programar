N=int(input("Digite o número inteiro: \n"))
if (N<0):
    N=N*-1
else:
    N=N
print(f"Número inteiro positivo: {N}")