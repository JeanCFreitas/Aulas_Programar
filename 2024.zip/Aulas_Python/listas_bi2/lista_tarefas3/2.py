num=20
while(num>0):
    if num%2==0:
        print(f"O número {num} é Par")
    num=num-1