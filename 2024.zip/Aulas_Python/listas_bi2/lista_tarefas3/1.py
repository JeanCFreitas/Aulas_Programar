num=0
while(num<20):
    num=num+1
    print(f'Número atual é {num}')