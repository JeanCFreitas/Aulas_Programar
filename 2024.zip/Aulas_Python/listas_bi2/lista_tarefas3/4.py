num=20
for num in 20:
    print(num)
    num=num-1

#Have to make it work