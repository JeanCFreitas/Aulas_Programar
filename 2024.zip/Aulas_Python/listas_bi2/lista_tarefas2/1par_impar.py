num=int(input('Digite Numero:'))
if num%2==0:
    print(f"{num} é Par")
else:
    print(f"{num} é Impar")