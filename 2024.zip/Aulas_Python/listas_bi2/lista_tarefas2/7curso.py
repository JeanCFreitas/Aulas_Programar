curso=int(input('Digite o numero do curso:'))
if (curso==1):
    print('Engenharia ')
elif (curso==2):
    print('Edificações ')
elif (curso==3):
    print('Sistemas Elétricos ')
elif (curso==4):
    print('Turismo  ')
elif (curso==5):
    print('Análise de Sistemas ')
else:
    print('Erro: Curso Invalido')