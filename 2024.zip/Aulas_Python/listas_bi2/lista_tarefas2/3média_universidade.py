import math
n1=float(input('Digite primeira nota:'))
n2=float(input('Digite segunda nota:'))
media=(n1+n2)/2
arredondar=math.ceil(media)
print(f'Média arrendondada: {arredondar}')