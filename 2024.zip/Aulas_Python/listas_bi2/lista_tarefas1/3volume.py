raio = float(input("Digite o raio:"))
altura = float(input("Digite a altura:"))
volume = 3.14159*((raio**2)*altura)
print("Volume:", '%.2f' %volume)