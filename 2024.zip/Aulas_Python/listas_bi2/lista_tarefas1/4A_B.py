A = float(input("Digite A:"))
B = float(input("Digite B:"))
print("Valor original A:", A)
print("Valor original B:", B)
A=B+A
B=A-B
A=A-B
print("Novo valor A:", A)
print("Novo valor B:", B)