num = float(input("Digite o número:"))
quad = num**2
print("Quadrado do próprio numero:", quad) 