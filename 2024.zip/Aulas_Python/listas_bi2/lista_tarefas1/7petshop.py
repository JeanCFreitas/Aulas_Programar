Nr_coelhos = float(input("Número de coelhos:"))
custo = ((Nr_coelhos*0.70)/18)+10
print("Custo da criação de coelhos:", '%.2f' %custo)