F = float(input("Digite a temperatura em graus Fahrenheit:"))
C = ((F-32)*5)/9
print("Temperatura em Celsius:", '%.2f' %C,"ºC")