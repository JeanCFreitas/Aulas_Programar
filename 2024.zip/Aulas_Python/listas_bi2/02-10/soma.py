a = float(input("Digite A:"))
b = float(input("Digite B:"))
soma = a + b
print (soma)