v1=float(input("Digite o primeiro valor:"))
v2=float(input("Digite o segundo valor:"))

if(v1>v2):
    print(f"O maior numero é {v1}, equanto o menor numero é {v2}")
else:
    print(f"O maior numero é {v2}, equanto o menor numero é {v1}")