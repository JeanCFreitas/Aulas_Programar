x=int(input('Entre com um numero:'))
z=x*x
print(z)
a=float(input('Digite uma nota:'))
b=a+a
print(b)
if (b>20):
    print(b+2)
else:
    print(b*5)