num=int(input('Digite um expoente qualquer:'))
pot=int(input('Digite uma potencia qualquer:'))
resul=num**pot
print(f'{num} elevado a {pot} = {resul}')