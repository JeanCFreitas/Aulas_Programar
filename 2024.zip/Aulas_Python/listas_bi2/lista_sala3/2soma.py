num=0
soma=0
while (num<100):
    num=num+1
    soma=soma+num
print (f'a soma de todos os numeros de 1 a 100 é igual a {soma}')