num=0
soma=0
while (num<=500):
    num=num+1
    if (num%2==0):
        soma=soma+num
print (f'a soma de todos os numeros pares de 1 a 500 é igual a {soma}')