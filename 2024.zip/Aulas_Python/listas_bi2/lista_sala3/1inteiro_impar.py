num=0
while (num<20):
    if num%2!=0:
        print(f"{num} é Impar")
    num=num+1