num=3
pot=0
while (pot<=15):
    resul=num**pot
    print(f'{num} elevado a {pot} = {resul}')
    pot=pot+1