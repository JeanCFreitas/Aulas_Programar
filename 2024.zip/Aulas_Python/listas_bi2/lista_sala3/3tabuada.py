num=int(input('Digite o numero que deseja ver a tabuada:'))
tabu=0
while (tabu<=10):
    resul=tabu*num
    print(f'{num} x {tabu} = {resul}')
    tabu=tabu+1