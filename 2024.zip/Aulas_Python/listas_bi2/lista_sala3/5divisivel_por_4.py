contador=1
while (contador<200):
    if contador%4==0:
        print(f'{contador} é divisivel por 4')
    contador=contador+1