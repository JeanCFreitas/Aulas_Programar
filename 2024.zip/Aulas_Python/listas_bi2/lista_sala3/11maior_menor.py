A=float(input('Digite primeiro numero:'))
B=float(input('Digite segundo numero:'))
C=float(input('Digite terceiro numero:'))
D=float(input('Digite quarto numero:'))
E=float(input('Digite quinto numero:'))
if (A>B and A>C and A>D and A>E):
    print(f'Maior número:{A}')
if (A<B and A<C and A<D and A<E):
    print(f'Menor número:{A}')
if (B>A and B>C and B>D and B>E):
    print(f'Maior número:{B}')
if (B<A and B<C and B<D and B<E):
    print(f'Menor número:{B}')
if (C>A and C>B and C>D and C>E):
    print(f'Maior número:{C}')
if (C<A and C<B and C<D and C<E):
    print(f'Menor número:{C}')
if (D>A and D>C and D>B and D>E):
    print(f'Maior número:{D}')
if (D<A and D<C and D<B and D<E):
    print(f'Menor número:{D}')
if (E>A and E>C and E>D and E>B):
    print(f'Maior número:{E}')
if (E<A and E<C and E<D and E<B):
    print(f'Menor número:{E}')