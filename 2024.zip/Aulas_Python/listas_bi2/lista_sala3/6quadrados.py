num=15
quad=0
while (num<=200):
    quad=num**2
    print(f'O quadrado de {num} é {quad}')
    num=num+1