#include <math.h>
int main() 
{
    float b,e,x,y,idade,genero,f,m;
    x=pow (b,e);
    y=sqrt (x);
    if (idade >=18) nd (genero=f);
}